﻿# Grants & Partnership Timeline

| Month | Target | Action | Status |
|-------|--------|--------|--------|
| 0–1 | Collab.Land + Zealy | Submit partnership briefs | Drafting |
| 2 | The Graph | Community council engagement | Planned |
| 3 | Binance Labs | Grant Wave Q2 2026 | Pending |
| 3 | Arbitrum Foundation | Ecosystem Grant Q2 | Pending |
| 4 | Integration Sprint | Launch co-marketing & dashboards | Upcoming |
