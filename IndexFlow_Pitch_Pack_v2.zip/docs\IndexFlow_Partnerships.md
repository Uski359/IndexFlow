﻿# IndexFlow Partnership Briefs

## Partner: Collab.Land
### Objective
Launch wallet-gated data channels that deliver verifiable analytics to token communities using IndexFlow proofs.

### Value Exchange
- **IndexFlow** supplies verifiable dashboards and alert feeds for community managers.
- **Collab.Land** unlocks distribution to 40k+ token-gated communities and co-marketing reach.

### Integration Draft
1. Embed IndexFlow GraphQL endpoints into Collab.Land bot widgets.
2. Offer Proof-of-SQL powered leaderboards & quest feedback in gated channels.
3. Share validator rewards with Collab.Land partner guild via $IFLW staking delegation.

### Contact Strategy
- Warm intro through Collab.Land ecosystem PMs (Telegram + email deck).
- Prepare co-branded demo and 2-page solution brief.
- Secure joint announcement slot on Collab.Land weekly community call.

### Timeline
- Week 1: Send deck + schedule discovery call.
- Week 2: Technical scoping and shared success metrics.
- Week 4: Pilot launch with two DAO communities.

---

## Partner: Zealy
### Objective
Drive validator and curator activation through quest-based onboarding and measurable incentives.

### Value Exchange
- **IndexFlow** gains gamified user education, validator quests, and referral analytics.
- **Zealy** expands quest catalog with verifiable data tasks and co-branded rewards.

### Integration Draft
1. Publish “IndexFlow Validator Bootcamp” questline with PoI verification tasks.
2. Automate quest completion checks using IndexFlow REST `/health` + GraphQL proofs.
3. Sponsor Zealy leaderboard rewards in $IFLW with monthly spotlight quests.

### Contact Strategy
- DM Zealy partnerships team with concise mission + quest mockups.
- Deliver 1-pager outlining KPIs (validators onboarded, datasets curated).
- Align on launch date for end-of-year data sprint.

### Timeline
- Week 0: Share brief + secure commitment for December questline.
- Week 2: Finalize quest logic & reward vault setup.
- Week 4: Launch quests with joint Twitter Spaces.

---

## Partner: The Graph Advocates
### Objective
Co-create verifiable subgraphs and cross-community workshops to accelerate adoption.

### Value Exchange
- **IndexFlow** taps into The Graph’s curator network and grant pathways.
- **Advocates** gain access to Proof-of-SQL tooling that enhances subgraph trust.

### Integration Draft
1. Host technical workshop: “Augmenting Subgraphs with Proof-of-Indexing”.
2. Publish reference repo combining IndexFlow proofs with The Graph subgraph outputs.
3. Propose joint bounty program for hybrid indexing use-cases.

### Contact Strategy
- Submit proposal to Advocates DAO + engage core contributors on Discord.
- Provide demo environment & workshop curriculum outline.
- Target upcoming Advocates community call for announcement.

### Timeline
- Month 1: Workshop proposal + content approval.
- Month 2: Run co-branded workshop & release reference repo.
- Month 3: Launch bounty round with shared funding.
